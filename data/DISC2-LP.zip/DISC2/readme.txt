Diccionari Informatitzat de l'Scrabble en Català, versió 2.14.21 - 11/09/2022
-----------------------------------------------------------------------------

Copyright 2012 -- 2023 Joan Montané joan(sense_spam)montane.cat

El «Diccionari Informatitzat de l'Scrabble en Català», DISC, té una llicència dual GPLv3 i CC-by-sa v3, a la vostra elecció

Per a més informació, visiteu:

http://diccionari.totescrable.cat


«Diccionari Informatitzat de l'Scrabble en Català» (DISC) is under a dual license (at your choose): GPLv3 and CC-by-sa v3

For more info, read (in Catalan):

http://diccionari.totescrable.cat


